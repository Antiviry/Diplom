package com.example.mdiplom

import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Email
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBindig
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var auh = FirebaseAuth.getInstance()

        binding.btnlogin.setOnClickListener {
            login()
        }
        binding.RedirectSignUpTV.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun login() {
        val email = binding.emailET.text.toString()
        val pass = binding.passwordET.text.toString()

        auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this) {
            if (it.isSuccessful) {
                Toast.makeText(
                    this,
                    "Успешно вошел в систему",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Не удалось войти в систему",
                    Toast.LENGTH_SHORT
                ).show()
            binding.RedirectSignUpTV.visibility = View.VISIBLE
            }
            }
        }
    }

enum class ActivityLoginBindig {

}
